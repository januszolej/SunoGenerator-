# Suno Generator – Android

Pierwsza wersja aplikacji do tworzenia tekstów piosenek i promptów Styles dla Suno.

## Uruchomienie
1. Otwórz folder w Android Studio.
2. Pozwól Android Studio pobrać Gradle i Android Gradle Plugin.
3. Zbuduj aplikację i uruchom na telefonie/emulatorze.

Wersja 1 działa lokalnie i nie wymaga klucza API. Generator jest bazowy; kolejnym krokiem może być integracja z modelem AI, historia utworów, zapis projektów, eksport TXT oraz gotowe profile gatunków.
