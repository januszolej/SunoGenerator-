package pl.sunogenerator.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.*
import android.graphics.Color
import android.text.InputType
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var topic: EditText
    private lateinit var mode: Spinner
    private lateinit var narration: Spinner
    private lateinit var music: Spinner
    private lateinit var genre: Spinner
    private lateinit var mood: Spinner
    private lateinit var voice: Spinner
    private lateinit var length: Spinner
    private lateinit var result: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("suno", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,18,22,18); setBackgroundColor(Color.rgb(248,247,251)) }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin=10 }
        box.addView(TextView(this).apply { text="🎵 Suno Generator PRO"; textSize=27f; setTextColor(Color.rgb(44,25,72)) }, lp())
        box.addView(TextView(this).apply { text="AI tworzy pełną piosenkę + Styles. Historia zapisuje się w telefonie."; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,4,0,14) }, lp())

        box.addView(label("TRYB TWORZENIA"))
        mode=spinner(arrayOf("🎵 Piosenka – śpiewana", "🎙 Poezja + muzyka – recytowana")); box.addView(mode,lp())
        box.addView(label("TEMAT / HISTORIA"))
        topic=EditText(this).apply { hint="Np. 40 lat małżeństwa Ani i Grzegorza, poznali się w Zgorzelcu..."; minLines=4; gravity=Gravity.TOP; textSize=16f }
        box.addView(topic,lp())
        genre=spinner(arrayOf("Ballada","Pop","Rock","Afro House","Dance","Disco Polo","Reggae","Country","Biesiadna","Elektroniczna")); add(box,"GATUNEK",genre,lp())
        mood=spinner(arrayOf("Romantyczny","Wesoły","Wzruszający","Energetyczny","Nostalgiczny","Taneczny","Podniosły","Letni")); add(box,"NASTRÓJ",mood,lp())
        voice=spinner(arrayOf("Męski","Żeński","Duet","Chór / grupowy")); add(box,"WOKAL",voice,lp())
        length=spinner(arrayOf("Krótka – 2 zwrotki","Standard – 3 zwrotki","Rozbudowana – 4 zwrotki","Długa – 5 zwrotek")); add(box,"DŁUGOŚĆ",length,lp())
        narration=spinner(arrayOf("Spokojna recytacja","Wzruszająca opowieść","Narracja filmowa","Dramatyczna recytacja","Intymny półszept","Czytanie poezji","Podcastowa narracja","Dwa głosy – dialog")); add(box,"SPOSÓB RECYTACJI",narration,lp())
        music=spinner(arrayOf("Piano + delikatne smyczki","Gitara akustyczna + ambient","Cinematic + orkiestra","Ambient + pad’y","Jazz + kontrabas","Elektronika + subtelny beat","Afro House – muzyka w tle","Minimalistyczne piano")); add(box,"MUZYKA W TLE POEZJI",music,lp())
        narration.visibility=View.GONE; music.visibility=View.GONE
        mode.onItemSelectedListener=object: AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent:AdapterView<*>?) {} ; override fun onItemSelected(parent:AdapterView<*>?, view:View?, position:Int, id:Long){ val poem=position==1; narration.visibility=if(poem)View.VISIBLE else View.GONE; music.visibility=if(poem)View.VISIBLE else View.GONE; status.text=if(poem) "🎙 Tryb poezji: głos ma mówić, muzyka pozostaje w tle." else "🎵 Tryb piosenki: tekst przeznaczony do śpiewania." } }

        val presets=Button(this).apply { text="🎛 GOTOWE STYLE"; setOnClickListener { showPresets() } }
        box.addView(presets,lp())
        val ai=Button(this).apply { text="✨ GENERUJ Z AI"; textSize=17f; setOnClickListener { generateAI() } }
        box.addView(ai,lp())
        val local=Button(this).apply { text="⚡ GENERUJ BEZ AI (OFFLINE)"; setOnClickListener { generateLocal(); saveHistory(result.text.toString()) } }
        box.addView(local,lp())
        status=TextView(this).apply { setTextColor(Color.rgb(75,55,100)); textSize=13f; setPadding(4,3,4,8) }; box.addView(status,lp())

        box.addView(label("LYRICS + SUNO STYLES"))
        result=EditText(this).apply { hint="Wynik pojawi się tutaj…"; minLines=18; gravity=Gravity.TOP; textSize=15f; setTextIsSelectable(true) }
        box.addView(result,lp())
        val copy=Button(this).apply { text="📋 KOPIUJ CAŁOŚĆ"; setOnClickListener { copyAll() } }; box.addView(copy,lp())
        val history=Button(this).apply { text="🕘 HISTORIA"; setOnClickListener { showHistory() } }; box.addView(history,lp())
        val settings=Button(this).apply { text="⚙ USTAWIENIA AI"; setOnClickListener { showSettings() } }; box.addView(settings,lp())
        scroll.addView(box); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }

    private fun add(box:LinearLayout, title:String, view:View, lp:LinearLayout.LayoutParams){ box.addView(label(title)); box.addView(view,lp) }
    private fun label(s:String)=TextView(this).apply{ text=s; textSize=11f; setTextColor(Color.GRAY); setPadding(2,4,2,2) }
    private fun spinner(a:Array<String>)=Spinner(this).apply{ adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,a) }

    private fun userPrompt():String {
        val n=length.selectedItem.toString().firstOrNull{it.isDigit()}?.digitToInt() ?: 3
        if(mode.selectedItemPosition==1) return """
Stwórz kompletny polski utwór poetycki przeznaczony do Suno w trybie SPOKEN WORD / SPOKEN WORD POETRY. Temat: ${topic.text.trim()}. Nastrój emocjonalny: ${mood.selectedItem}. Sposób recytacji: ${narration.selectedItem}. Muzyka w tle: ${music.selectedItem}. Długość: około $n części tekstu.

NAJWAŻNIEJSZE: tekst ma być MÓWIONY/RECYTOWANY, a nie śpiewany. Nie twórz melodii wokalnej. Nie stosuj rapu. Głos ma prowadzić opowieść, a muzyka ma pozostać pod nim i budować atmosferę. Stosuj naturalne zdania, pauzy, oddechy i krótkie wersy. Tekst ma brzmieć jak profesjonalna poezja mówiona, a nie jak piosenka pozbawiona melodii.

Użyj czytelnych tagów Suno, np. [Intro - instrumental], [Spoken Word], [Pause], [Music rises], [Spoken Word - emotional], [Instrumental], [Outro - fade]. Nie używaj [Chorus] jako śpiewanego refrenu. Możesz stworzyć powracającą frazę, ale musi być wypowiadana.

Na końcu dodaj osobną sekcję --- SUNO STYLES --- i przygotuj profesjonalny prompt: Spoken Word Poetry, Polish spoken narration, ${narration.selectedItem}, ${music.selectedItem}, ${mood.selectedItem}, intimate clear voice, natural speech rhythm, expressive pauses, music underneath narration, no singing, no melodic vocals, no rap, no autotune, cinematic depth, voice clearly above instrumental, controlled dynamics, tasteful transitions.

Nie dodawaj komentarzy poza Lyrics i SUNO STYLES.
""".trimIndent()
        return "Napisz kompletną polską piosenkę do Suno. Temat: ${topic.text.trim()}. Gatunek: ${genre.selectedItem}. Nastrój: ${mood.selectedItem}. Wokal: ${voice.selectedItem}. Liczba zwrotek: $n. Użyj tagów [Intro], [Verse], [Chorus], [Bridge], [Instrumental], [Outro]. Refren ma być chwytliwy i powtarzalny, zwrotki konkretne i obrazowe, bez banalnych wypełniaczy. Zachowaj naturalny język polski. Na końcu dodaj osobną sekcję --- SUNO STYLES --- z profesjonalnym opisem gatunku, tempa, instrumentów, produkcji, wokalu i dynamiki. Nie dodawaj komentarzy poza wynikiem."
    }

    private fun generateAI(){
        val key=prefs.getString("api_key","")?.trim().orEmpty()
        if(key.isEmpty()) { showSettings(); Toast.makeText(this,"Najpierw wpisz klucz API w Ustawieniach AI.",Toast.LENGTH_LONG).show(); return }
        status.text="⏳ AI tworzy piosenkę…"
        executor.execute {
            try {
                val url=URL("https://api.openai.com/v1/responses")
                val c=url.openConnection() as HttpURLConnection
                c.requestMethod="POST"; c.connectTimeout=30000; c.readTimeout=120000; c.doOutput=true
                c.setRequestProperty("Authorization","Bearer $key"); c.setRequestProperty("Content-Type","application/json")
                val model=prefs.getString("model","gpt-6-luna") ?: "gpt-6-luna"
                val body=JSONObject().apply { put("model",model); put("input",userPrompt()); put("max_output_tokens",2500) }.toString()
                c.outputStream.use{it.write(body.toByteArray(StandardCharsets.UTF_8))}
                val code=c.responseCode
                val text=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()}
                if(code !in 200..299) throw Exception("HTTP $code: $text")
                val json=JSONObject(text); val out=extractOutputText(json)
                main.post { result.setText(out); status.text="✅ Gotowe. Zapisano w historii."; saveHistory(out) }
            } catch(e:Exception){ main.post { status.text="❌ Błąd AI: ${e.message}"; Toast.makeText(this,"Nie udało się wygenerować. Sprawdź klucz API i internet.",Toast.LENGTH_LONG).show() } }
        }
    }

    private fun extractOutputText(j:JSONObject):String {
        if(j.has("output_text")) return j.optString("output_text")
        val out=j.optJSONArray("output") ?: return j.toString(2)
        val sb=StringBuilder()
        for(i in 0 until out.length()) { val item=out.optJSONObject(i) ?: continue; val content=item.optJSONArray("content") ?: continue; for(k in 0 until content.length()){ val x=content.optJSONObject(k) ?: continue; val t=x.optString("text",""); if(t.isNotEmpty()) sb.append(t) } }
        return sb.toString().ifEmpty{j.toString(2)}
    }

    private fun generateLocal(){
        if(mode.selectedItemPosition==1){ generatePoetryLocal(); return }
        val t=topic.text.toString().trim().ifEmpty{"miłość, wspólne chwile i piękne wspomnienia"}; val g=genre.selectedItem.toString(); val m=mood.selectedItem.toString(); val v=voice.selectedItem.toString(); val n=length.selectedItem.toString().firstOrNull{it.isDigit()}?.digitToInt() ?: 3
        val sb=StringBuilder("[Intro]\nDelikatne instrumentalne otwarcie, stopniowo narastająca atmosfera.\n\n")
        for(i in 1..n){ sb.append("[Verse]\nOpowiedz obrazowo o: $t. Pokaż emocje, miejsca i wspólne chwile.\nKażda zwrotka powinna wnosić nowy szczegół do historii.\n\n")
            sb.append("[Chorus]\nTo nasz czas, nasza historia, nasze sny,\nniech ta melodia zostanie z nami na długie dni.\n$t — niech dziś wybrzmi w każdym słowie.\n\n") }
        sb.append("[Bridge]\nMuzyka na chwilę zwalnia, pojawia się emocjonalne przejście i powrót do finałowego refrenu.\n\n[Instrumental]\nCharakterystyczny motyw dla gatunku $g.\n\n[Outro]\nPowtórz główną frazę refrenu i zakończ miękkim fade out.\n\n--- SUNO STYLES ---\n$g, $m, $v vocal, Polish lyrics, catchy chorus, emotional storytelling, memorable hook, dynamic arrangement, polished modern production, clear vocal, tasteful instrumental solo")
        result.setText(sb.toString()); status.text="⚡ Wygenerowano lokalnie — bez API." }


    private fun generatePoetryLocal(){
        val t=topic.text.toString().trim().ifEmpty{"wspomnienia, miłość i upływający czas"}
        val sb=StringBuilder("[Intro - instrumental]\nDelikatne otwarcie muzyczne, głos pojawia się dopiero po kilku sekundach.\n\n[Spoken Word - intimate]\n$t...\n\n[Pause]\n\n[Spoken Word - emotional]\nTo nie jest historia, którą trzeba śpiewać.\nTo historia, którą trzeba powiedzieć...\n\n[Music rises]\nNiech muzyka zostanie pod słowami,\na chwilę głośniejsza, potem znów odsunie się w tło.\n\n[Spoken Word - warm]\nA kiedy zapadnie cisza,\nniech zostanie to, co najważniejsze.\n\n[Instrumental]\n${music.selectedItem} — spokojna kulminacja bez wokalu.\n\n[Outro - fade]\nOstatnie słowa wypowiedziane ciszej, muzyka powoli zanika.\n\n--- SUNO STYLES ---\nSpoken Word Poetry, Polish spoken narration, ${narration.selectedItem}, ${music.selectedItem}, ${mood.selectedItem}, intimate clear voice, natural speech rhythm, expressive pauses, music underneath narration, NO singing, NO melodic vocals, NO rap, no autotune, cinematic atmosphere, voice clearly above instrumental, subtle dynamics, tasteful fade out")
        result.setText(sb.toString()); status.text="🎙 Wygenerowano poezję — tekst do RECYTACJI, muzyka w tle."
    }

    private fun copyAll(){ val cm=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("Suno",result.text.toString())); Toast.makeText(this,"Skopiowano do schowka",Toast.LENGTH_SHORT).show() }

    private fun saveHistory(text:String){ if(text.isBlank())return; val old=prefs.getString("history","").orEmpty(); val entries=old.split("\\n---ENTRY---\\n").filter{it.isNotBlank()}.toMutableList(); entries.add(0,text); while(entries.size>10) entries.removeLast(); prefs.edit().putString("history",entries.joinToString("\n---ENTRY---\n")).apply() }

    private fun showHistory(){
        val entries=prefs.getString("history","").orEmpty().split("\\n---ENTRY---\\n").filter{it.isNotBlank()}
        if(entries.isEmpty()){Toast.makeText(this,"Historia jest pusta.",Toast.LENGTH_SHORT).show();return}
        val names=entries.mapIndexed{i,e->"${i+1}. "+e.lineSequence().firstOrNull{it.startsWith("[Verse]")||it.startsWith("[Intro]")}?.take(55)}.toTypedArray()
        AlertDialog.Builder(this).setTitle("Historia").setItems(names){_,which->result.setText(entries[which]);status.text="Załadowano zapis z historii."}.setNegativeButton("Zamknij",null).show()
    }

    private fun showPresets(){
        val presets=arrayOf("Romantyczna ballada","Afro House – letni","Taneczny hit","Rockowa historia","Biesiadna impreza","Wzruszający jubileusz")
        AlertDialog.Builder(this).setTitle("Wybierz profil").setItems(presets){_,i->
            when(i){0->{genre.setSelection(0);mood.setSelection(0)};1->{genre.setSelection(3);mood.setSelection(7)};2->{genre.setSelection(4);mood.setSelection(5)};3->{genre.setSelection(2);mood.setSelection(3)};4->{genre.setSelection(7);mood.setSelection(1)};5->{genre.setSelection(0);mood.setSelection(2)}}
        }.show()
    }

    private fun showSettings(){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,10,30,0)}
        val key=EditText(this).apply{hint="Klucz API";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(prefs.getString("api_key","") ?: "")}
        val model=EditText(this).apply{hint="Model";setText(prefs.getString("model","gpt-6-luna") ?: "gpt-6-luna")}
        layout.addView(key);layout.addView(model)
        AlertDialog.Builder(this).setTitle("Ustawienia AI").setMessage("Klucz jest przechowywany lokalnie na telefonie. W aplikacji klienckiej nie jest to rozwiązanie odpowiednie do dystrybucji publicznej — do wersji produkcyjnej warto użyć własnego serwera pośredniczącego.").setView(layout).setPositiveButton("Zapisz"){_->prefs.edit().putString("api_key",key.text.toString().trim()).putString("model",model.text.toString().trim()).apply()}.setNegativeButton("Anuluj",null).show()
    }
}
