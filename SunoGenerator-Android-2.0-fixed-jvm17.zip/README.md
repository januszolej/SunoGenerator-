# Suno Generator 2.0

Kompletny projekt Android z trybem Piosenka oraz Poezja + muzyka.
