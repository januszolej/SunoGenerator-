package pl.sunogenerator

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val topic = findViewById<EditText>(R.id.topic)
        val mode = findViewById<Spinner>(R.id.mode)
        val result = findViewById<TextView>(R.id.result)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("🎵 Piosenka", "🎙️ Poezja + muzyka"))
        findViewById<Button>(R.id.generate).setOnClickListener {
            val subject = topic.text.toString().ifBlank { "moja historia" }
            val style = if (mode.selectedItemPosition == 1) "Spoken Word / Spoken Word Poetry, NO singing, NO melodic vocals, NO rap, atmospheric instrumental" else "Polish song, catchy chorus, expressive vocals, modern production"
            result.text = """SUNO STYLES\n\n$style\n\nLYRICS\n\n[Intro]\nInstrumental introduction.\n\n[Verse]\n$subject — historia opowiedziana muzyką.\n\n[Chorus]\nTo jest nasza opowieść,\nktórą chcemy zapamiętać.\n\n[Bridge]\nNajważniejsze chwile zostają z nami.\n\n[Outro]\nInstrumental fade out."""
        }
    }
}
